#ifndef RANGER_VERSION
#define RANGER_VERSION "0.2.8.82"
#endif
