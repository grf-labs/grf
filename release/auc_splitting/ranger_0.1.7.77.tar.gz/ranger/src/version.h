#ifndef RANGER_VERSION
#define RANGER_VERSION "0.1.7.77"
#endif
