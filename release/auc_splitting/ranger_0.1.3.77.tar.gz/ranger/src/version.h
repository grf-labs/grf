#ifndef RANGER_VERSION
#define RANGER_VERSION "0.1.3.77"
#endif
