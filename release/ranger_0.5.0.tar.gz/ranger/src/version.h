#ifndef RANGER_VERSION
#define RANGER_VERSION "0.5.0"
#endif
