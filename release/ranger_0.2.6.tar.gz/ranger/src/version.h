#ifndef RANGER_VERSION
#define RANGER_VERSION "0.2.6"
#endif
