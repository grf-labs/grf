#ifndef RANGER_VERSION
#define RANGER_VERSION "0.1.4"
#endif
