#ifndef RANGER_VERSION
#define RANGER_VERSION "0.2.0"
#endif
