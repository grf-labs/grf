library(testthat)
library(ranger)

test_check("ranger")