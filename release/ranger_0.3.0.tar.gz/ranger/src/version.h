#ifndef RANGER_VERSION
#define RANGER_VERSION "0.3.0"
#endif
