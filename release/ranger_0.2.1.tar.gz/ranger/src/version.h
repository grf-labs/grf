#ifndef RANGER_VERSION
#define RANGER_VERSION "0.2.1"
#endif
