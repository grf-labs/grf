#ifndef RANGER_VERSION
#define RANGER_VERSION "0.1.9"
#endif
