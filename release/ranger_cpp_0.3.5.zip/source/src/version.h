#ifndef RANGER_VERSION
#define RANGER_VERSION "0.3.5"
#endif
