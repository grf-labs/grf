#ifndef RANGER_VERSION
#define RANGER_VERSION "0.4.0"
#endif
