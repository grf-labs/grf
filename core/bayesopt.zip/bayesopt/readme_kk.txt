install the linrary in a different path:

cmake -DCMAKE_INSTALL_PREFIX=/afs/.ir/users/k/u/kunkuang/private/KKun/packages
make
make install