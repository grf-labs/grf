% NLOPT_LD_SLSQP: Sequential Quadratic Programming (SQP) (local, derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_SLSQP
  val = 40;
