#include <iostream>

#include <ctime>
#include "bayesopt/bayesopt.h"                 // For the C API
#include "bayesopt/bayesopt.hpp"               // For the C++ API
#include <boost/numeric/ublas/assignment.hpp> // <<= op assigment

using namespace std;

int main() 
{
    cout << "Hello, World!";
    return 0;
}