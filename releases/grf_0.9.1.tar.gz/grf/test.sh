#!/bin/bash

var=`ls *.cpp`