library(grf)
set.seed(42)
n = 5000; p = 2000
X = matrix(rnorm(n * p), n, p)
Y = rnorm(5000)

system.time(regression_forest(X, Y, num.trees=2000))

#write.table(X, file="../core/test/forest/resources/performance_test.csv", row.names=FALSE, col.names=TRUE)