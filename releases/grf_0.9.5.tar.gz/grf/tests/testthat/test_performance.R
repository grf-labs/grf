library(grf)
set.seed(42)
n = 4000; p = 10
X = matrix(rnorm(n * p), n, p)
Y = 0.5 * X[,1] + rnorm(n)

#r.forest = regression_forest(X, Y, num.trees=2000)

data = as.matrix(cbind(X, Y))
write.table(data, file="../core/test/forest/resources/high_signal_test.csv", row.names=FALSE, col.names=FALSE)