library(testthat)
library(gradient.forest)

test_check("gradient.forest")